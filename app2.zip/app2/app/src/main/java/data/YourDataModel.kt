package data

data class YourDataModel(
    val id: Int,
    val name: String,
    val description: String?,
    val price: Double
)